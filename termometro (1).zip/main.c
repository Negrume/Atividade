/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby,
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.
  2) Crie um programa para converter a temperatura de Celsius para Fahrenheit.
Fahrenheit = (Celsius * 1,8) + 32


*******************************************************************************/
#include <stdio.h>

int main()
{
    float Celsius, Fahrenheit;
    scanf("%f", &Celsius);

    Fahrenheit = (Celsius * 1.8)+ 32;
    printf("%2.f", Fahrenheit);

    return 0;
}

