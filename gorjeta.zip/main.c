#include <stdio.h>

int main() 
{
    float valorConta;
    float porcentagemGorjeta;
    float gorjeta;
    float totalAPagar;


    printf("Digite o valor da conta: R$ ");
    scanf("%f", &valorConta);


    printf("Digite a porcentagem da gorjeta: ");
    scanf("%f", &porcentagemGorjeta);


    gorjeta = (porcentagemGorjeta / 100) * valorConta;
    totalAPagar = valorConta + gorjeta;

    
    printf("Valor da conta: R$ %.2f", valorConta);
    printf("Gorjeta: R$ %.2f", gorjeta);
    printf("Total a ser pago: R$ %.2f", totalAPagar);

    return 0;
}