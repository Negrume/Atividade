/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.
3) Crie um programa para determinar se um ano é bissexto. Um ano é bissexto
se for divisível por 4 e não for divisível por 100 ou for divisível por 400

*******************************************************************************/
#include <stdio.h>

int main()
{
    int ano;
    
    printf("Digite uma ano: ");
    scanf("%d", &ano);
  
    
    if((ano % 4 == 0 && ano % 100 !=0 ) || (ano % 400 == 0))
    {
        printf("%d é um ano bissexto.\n", ano);
    }
    else
    {
        printf("%d esse ano não é um ano bissexto \n", ano);
    }

    return 0;
}
